<?php get_header(); ?>
<div class="container mt-5">
    <h1 class="text-center" style="font-size: 6em;font-weight: bold;opacity: .3;">404</h1>
    <h1 class="text-center">Không tồn tại trang</h1>
</div>
<?php get_footer(); ?>